# 🎵 Retro Board Web App

A collaborative retro board with:
- Sticky notes
- Reactions (👍 ⭐ +1)
- Background music
- Firebase real-time sync
- Tailwind CSS styling
- Export to PDF (Coming soon!)

## 🔧 Setup
1. Replace Firebase config in `index.html`
2. Run `firebase init` and `firebase deploy`
3. Use GitHub Actions for CI/CD

Enjoy your retro sessions! 🚀
